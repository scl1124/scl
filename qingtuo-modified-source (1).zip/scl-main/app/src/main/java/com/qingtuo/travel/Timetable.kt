package com.qingtuo.travel

/**
 * 一个班次。times 与所在线路的 stations 一一对应，null 表示该站不经过/不进站。
 * 为保护隐私，司机姓名和手机号不收录。
 */
data class Trip(
    val no: String,
    val plate: String,
    val times: List<String?>,
    val cancelled: Boolean = false,
)

data class RouteTable(
    val title: String,
    val stations: List<String>,
    val boardStation: String,
    val extraStation: String,
    val extraLabel: String,
    val trips: List<Trip>,
) {
    fun timeAt(trip: Trip, station: String): String? {
        val index = stations.indexOf(station)
        return if (index >= 0) trip.times.getOrNull(index) else null
    }
}

private fun t(no: String, plate: String, raw: String, cancelled: Boolean = false): Trip =
    Trip(
        no = no,
        plate = plate,
        times = raw.trim().split(Regex("\\s+")).map { if (it == "-") null else it },
        cancelled = cancelled,
    )

/** 数据来源：客车客服发布的运行计划（10月12日）。第一版为内置数据。 */
object Timetable {
    const val DATE_LABEL = "10月12日"
    const val MONTH = 10
    const val DAY = 12

    const val SERVICE_PHONE = "15563690268"
    const val AMAP_URL = "https://surl.amap.com/1l9BAcuCl6S8"
    const val XINTUYUN_URL = "https://m.xintuyun.cn/html/index.html?ttsid=111"
    const val BAIDU_URL = "https://jiaotong.baidu.com/m/congestion/country/city"

    const val TIP = "车站发车时间为准确时间，到达每个站点时间为大概时间，不为准确到达时间，请提前到相应站点候车！"

    val priceNotes = listOf(
        "蒙阴→临沂 早班（5:30、6:30）班次，优惠票价15元/人，通过泉桥后，优惠票价10元/人。",
        "蒙阴→临沂 7:30班次，优惠票价20元/人，通过赵峪后，优惠票价15元/人，通过双堠后，执行原票价。",
    )

    private val toLinyiStations = listOf(
        "蒙阴车站", "转盘路", "由由东门", "县医院东门", "大站",
        "桃墟", "界牌", "垛庄", "双堠", "青驼",
    )

    private val toMengyinStations = listOf(
        "隆达车站", "临沂总站", "南坊北站", "俄庄", "枣沟头",
        "半程", "青驼", "双堠", "垛庄",
    )

    /** 蒙阴 → 临沂：在青驼上车去临沂，看青驼那一列。 */
    private val toLinyi = RouteTable(
        title = "青驼 → 临沂",
        stations = toLinyiStations,
        boardStation = "青驼",
        extraStation = "蒙阴车站",
        extraLabel = "蒙阴发车",
        trips = listOf(
            t("1", "鲁Q02830D", "5:20 5:25 5:30 5:45 5:55 6:05 6:15 6:25 6:45 6:55"),
            t("4", "鲁Q09369D", "6:30 6:35 6:40 6:55 7:05 7:15 7:25 7:35 7:55 8:05"),
            t("5", "鲁Q06825D", "7:30 7:35 7:40 7:55 8:05 8:15 8:25 8:35 8:55 9:05"),
            t("8", "鲁Q363JN", "8:30 8:35 8:40 - 8:55 9:05 9:15 9:25 9:45 9:55"),
            t("2", "鲁Q00879D", "9:10 9:15 9:20 9:35 9:45 9:55 10:05 10:15 10:35 10:45"),
            t("6", "鲁Q02020D", "10:30 10:35 10:40 10:55 11:05 11:15 11:25 11:35 11:55 12:05"),
            t("", "", "11:00 11:05 11:10 11:25 11:35 11:45 11:55 12:05 12:25 12:35", cancelled = true),
            t("3", "鲁Q03516D", "12:00 12:05 12:10 12:25 12:35 12:45 12:55 13:05 13:25 13:35"),
            t("7", "鲁Q00090D", "13:10 13:15 13:20 13:35 13:45 13:55 14:05 14:15 14:35 14:45"),
            t("1", "鲁Q02830D", "13:50 13:55 14:00 14:15 14:25 14:35 14:45 14:55 15:15 15:25"),
            t("4", "鲁Q09369D", "14:40 14:45 14:50 15:05 15:15 15:25 15:35 15:45 16:05 16:15"),
            t("5", "鲁Q06825D", "15:20 15:25 15:30 15:45 15:55 16:05 16:15 16:25 16:45 16:55"),
            t("2", "鲁Q00879D", "16:10 16:15 16:20 16:35 16:45 16:55 17:05 17:15 17:35 17:45"),
            t("6", "鲁Q02020D", "17:40 17:45 17:50 18:05 18:15 18:25 18:35 18:45 19:05 19:15"),
        ),
    )

    /** 临沂 → 蒙阴：从临沂回青驼，看临沂总站上车、青驼下车。 */
    private val toMengyin = RouteTable(
        title = "临沂 → 青驼",
        stations = toMengyinStations,
        boardStation = "临沂总站",
        extraStation = "青驼",
        extraLabel = "约到青驼",
        trips = listOf(
            t("6", "鲁Q02020D", "6:40 7:00 7:20 7:30 7:35 7:45 8:05 8:15 8:50"),
            t("3", "鲁Q03516D", "7:40 8:10 8:30 8:40 8:45 8:55 9:15 9:25 10:00"),
            t("7", "鲁Q00090D", "8:30 8:50 9:10 9:20 9:25 9:35 9:55 10:05 10:40"),
            t("1", "鲁Q02830D", "9:30 10:00 10:20 10:30 10:35 10:45 11:05 11:15 11:50"),
            t("4", "鲁Q09369D", "10:40 11:00 11:20 11:30 11:35 11:45 12:05 12:15 12:50"),
            t("5", "鲁Q06825D", "11:40 12:00 12:20 12:30 12:35 12:45 13:05 13:15 13:50"),
            t("2", "鲁Q00879D", "12:15 12:45 13:05 13:15 13:20 13:30 13:50 14:00 14:35"),
            t("9", "鲁Q363JN", "13:00 13:30 13:50 14:00 14:05 14:15 14:35 14:45 15:20"),
            t("6", "鲁Q02020D", "14:20 14:40 15:00 15:10 15:15 15:25 15:45 15:55 16:30"),
            t("", "", "14:50 15:10 15:30 15:40 15:45 15:55 16:15 16:25 16:40", cancelled = true),
            t("3", "鲁Q03516D", "15:40 16:00 16:20 16:30 16:35 16:45 17:05 17:15 17:50"),
            t("7", "鲁Q00090D", "16:40 17:10 - 17:25 17:30 17:40 18:00 18:10 18:30"),
            t("1", "鲁Q02830D", "17:40 18:10 - 18:05 18:10 18:20 18:40 18:50 19:20"),
            t("4", "鲁Q09369D", "18:30 19:00 - 19:15 19:20 19:30 19:50 20:00 20:20"),
        ),
    )

    val routes: List<RouteTable> = listOf(toLinyi, toMengyin)
}
